#!/bin/bash
exec /bin/bash "$(dirname "$0")/Scripts/Start-Belgie-illustraties.command"
