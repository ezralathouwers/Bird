import SwiftUI
import MapKit
import UIKit

enum FieldGuideTheme {
    // Provisional: no approved screenshot has been supplied for sampling.
    static func sans(_ size: CGFloat = 17, relativeTo style: Font.TextStyle = .body) -> Font {
        .custom("DMSans-9ptRegular", size: size, relativeTo: style)
    }
    // Native muted cartography, shared by range, observation and location maps.
    static var mapStyle: MapStyle {
        .standard(elevation: .flat, emphasis: .muted,
                  pointsOfInterest: .excludingAll, showsTraffic: false)
    }
    static let controlCornerRadius: CGFloat = 18
    static let roundControlDiameter: CGFloat = 44
    // One physical stroke width for every navigation outline, independent of
    // icon size. SF Symbol weights alone do not guarantee identical widths.
    static let navigationStroke = StrokeStyle(lineWidth: 0.7, lineCap: .round, lineJoin: .round)
    static let navigationWhite = Color.white
    static let mapLegendBackground = Color(red: 0.995, green: 0.99, blue: 0.98)
    static let ivory = Color(red: 0.96, green: 0.95, blue: 0.92)
    static let beige = Color(red: 0.89, green: 0.86, blue: 0.82)
    static let selectedBeige = Color(red: 0.83, green: 0.79, blue: 0.73)
    // Opaque equivalent of 40% beige over ivory, so scrolled content cannot show through.
    static let searchControlBackground = Color(red: 0.932, green: 0.914, blue: 0.88)
    static let khaki = Color(red: 133.0 / 255, green: 131.0 / 255, blue: 107.0 / 255)
    static let navigationOlive = Color(red: 124.0 / 255, green: 135.0 / 255, blue: 48.0 / 255)
    static let mutedIcon = Color(red: 181.0 / 255, green: 165.0 / 255, blue: 142.0 / 255)
    static let taupe = Color(red: 107.0 / 255, green: 104.0 / 255, blue: 100.0 / 255)
    // Neutral warm grey text (#4B4946), shared with the observation button fill.
    static let charcoal = Color(red: 75.0 / 255, green: 73.0 / 255, blue: 70.0 / 255)
}

// Shared large sans-serif headings; Discover sets its own explicit line height.
struct LargeHeadingStyle: ViewModifier {
    private let size: CGFloat
    @ScaledMetric private var tracking: CGFloat

    init(size: CGFloat = 34) {
        self.size = size
        _tracking = ScaledMetric(wrappedValue: size * 0.01, relativeTo: .largeTitle)
    }

    func body(content: Content) -> some View {
        content
            .font(FieldGuideTheme.sans(size, relativeTo: .largeTitle).weight(.medium).leading(.tight))
            .tracking(tracking)
            .fixedSize(horizontal: false, vertical: true)
    }
}

struct RoundedSearchField: ViewModifier {
    func body(content: Content) -> some View {
        content
            .textFieldStyle(.plain)
            .padding(.horizontal, 14)
            .padding(.vertical, 10)
            .frame(minHeight: 44)
            .background(FieldGuideTheme.navigationWhite,
                        in: RoundedRectangle(cornerRadius: FieldGuideTheme.controlCornerRadius, style: .continuous))
            .overlay {
                RoundedRectangle(cornerRadius: FieldGuideTheme.controlCornerRadius, style: .continuous)
                    .strokeBorder(FieldGuideTheme.beige, lineWidth: 0.75)
                    .allowsHitTesting(false)
            }
    }
}

// Tracking is expressed as -0.02 em and follows the same Dynamic Type scale
// as the font, so headings and small species names use the same proportion.
struct SerifText: View {
    private let value: String
    private let baseSize: CGFloat
    private let style: Font.TextStyle
    @ScaledMetric private var scaledSize: CGFloat

    init(_ value: String, size: CGFloat, relativeTo style: Font.TextStyle) {
        self.value = value
        self.baseSize = size
        self.style = style
        _scaledSize = ScaledMetric(wrappedValue: size, relativeTo: style)
    }

    var body: some View {
        Text(value)
            .font(.custom("Fraunces-9ptBlack", size: baseSize, relativeTo: style).weight(.regular))
            .tracking(-0.02 * scaledSize)
    }
}

struct RoundAction: View {
    @ScaledMetric(relativeTo: .body) private var iconSize: CGFloat = 17
    let symbol: String
    let label: String
    let action: () -> Void
    var body: some View {
        Button(action: action) {
            FineControlIcon(symbol: symbol, size: iconSize)
                .frame(width: FieldGuideTheme.roundControlDiameter, height: FieldGuideTheme.roundControlDiameter)
                .background(Circle().stroke(FieldGuideTheme.beige, lineWidth: 0.75))
        }
        .accessibilityLabel(label)
    }
}

// Explicit controls avoid iOS's automatic glass toolbar treatment.
struct SpeciesBackButton: View {
    var label = "Terug"
    let action: () -> Void
    var body: some View {
        Button(action: action) {
            Image(systemName: "chevron.left")
                .font(.system(size: 22, weight: .light))
                .frame(width: 44, height: 44, alignment: .leading)
                .contentShape(Rectangle())
        }.buttonStyle(.plain).foregroundStyle(FieldGuideTheme.charcoal)
            .accessibilityLabel(label)
    }
}

struct MapCloseButton: View {
    let label: String
    let action: () -> Void
    var body: some View {
        Button(action: action) {
            FineControlIcon(symbol: "xmark", size: 20)
                .foregroundStyle(FieldGuideTheme.charcoal)
                .frame(width: 44, height: 44)
                .background(FieldGuideTheme.ivory, in: Circle())
        }.buttonStyle(.plain).accessibilityLabel(label)
    }
}

struct LocationOutlineMark: Shape {
    func path(in rect: CGRect) -> Path {
        var path = Path()
        path.move(to: CGPoint(x: 10.5, y: 21.5))
        path.addCurve(to: CGPoint(x: 3, y: 9), control1: CGPoint(x: 8, y: 18), control2: CGPoint(x: 3, y: 14))
        path.addCurve(to: CGPoint(x: 21, y: 9), control1: CGPoint(x: 3, y: -2), control2: CGPoint(x: 21, y: -2))
        path.addCurve(to: CGPoint(x: 13.5, y: 21.5), control1: CGPoint(x: 21, y: 14), control2: CGPoint(x: 16, y: 18))
        path.addQuadCurve(to: CGPoint(x: 10.5, y: 21.5), control: CGPoint(x: 12, y: 23.5))
        path.closeSubpath()
        path.addEllipse(in: CGRect(x: 9, y: 6, width: 6, height: 6))
        return path.applying(CGAffineTransform(scaleX: rect.width / 24, y: rect.height / 24))
    }
}

struct EditOutlineMark: Shape {
    func path(in rect: CGRect) -> Path {
        var path = Path()
        path.move(to: CGPoint(x: 3, y: 21))
        path.addLine(to: CGPoint(x: 4.5, y: 15))
        path.addLine(to: CGPoint(x: 17, y: 2.5))
        path.addQuadCurve(to: CGPoint(x: 21.5, y: 7), control: CGPoint(x: 23, y: 1))
        path.addLine(to: CGPoint(x: 9, y: 19.5))
        path.closeSubpath()
        path.move(to: CGPoint(x: 14.5, y: 5))
        path.addLine(to: CGPoint(x: 19, y: 9.5))
        path.move(to: CGPoint(x: 4.5, y: 15))
        path.addLine(to: CGPoint(x: 9, y: 19.5))
        return path.applying(CGAffineTransform(scaleX: rect.width / 24, y: rect.height / 24))
    }
}

struct CountryFlagBadge: View {
    let code: String
    var diameter: CGFloat = 22
    var body: some View {
        Group {
            if let normalized = ObservationCountry.normalized(code), UIImage(named: "flag-" + normalized.lowercased()) != nil {
                Image("flag-" + normalized.lowercased()).resizable().scaledToFill().saturation(0.72)
            } else {
                FieldGuideTheme.beige.overlay { Image(systemName: "globe").foregroundStyle(FieldGuideTheme.taupe) }
            }
        }
        .frame(width: diameter, height: diameter).clipShape(Circle())
        .accessibilityLabel(ObservationCountry.name(for: code))
    }
}

struct CenteredPageHeader: View {
    let title: String
    var countryCode: String? = nil
    let back: () -> Void
    var body: some View {
        ZStack {
            HStack { SpeciesBackButton(action: back); Spacer(minLength: 0) }
            HStack(spacing: 8) {
                if let countryCode { CountryFlagBadge(code: countryCode, diameter: 22) }
                Text(title).font(FieldGuideTheme.sans(17, relativeTo: .headline))
                    .multilineTextAlignment(.center).accessibilityAddTraits(.isHeader)
            }.padding(.horizontal, 44)
        }
        .frame(minHeight: 44).padding(.horizontal, 20).padding(.top, 4).padding(.bottom, 8)
        .foregroundStyle(FieldGuideTheme.charcoal)
    }
}

struct ObservationTotal: View {
    let value: Int
    let label: String
    var body: some View {
        Text("\(value)").font(FieldGuideTheme.sans(60, relativeTo: .title3))
            .foregroundStyle(FieldGuideTheme.charcoal.opacity(0.35))
            .accessibilityLabel("\(value) \(value == 1 && label == "waarnemingen" ? "waarneming" : label)").accessibilityAddTraits(.isHeader)
    }
}

// The visible control has the same 18-point corners as search/text fields.
// The native date/time picker lives in a sheet rather than imposing its pill.
struct DateTimeField: View {
    @Environment(\.timeZone) private var timeZone
    let title: String
    @Binding var selection: Date
    let isDate: Bool
    var latestDate: Date? = nil
    @State private var presented = false
    private var value: String {
        var style = Date.FormatStyle(date: isDate ? .abbreviated : .omitted,
                                     time: isDate ? .omitted : .shortened)
        style.timeZone = timeZone
        return selection.formatted(style)
    }
    var body: some View {
        Button { presented = true } label: {
            Text(value).font(FieldGuideTheme.sans(17)).lineLimit(1)
                .modifier(RoundedSearchField())
        }.buttonStyle(.plain).accessibilityLabel(title).accessibilityValue(value)
            .sheet(isPresented: $presented) {
                NavigationStack {
                    Group {
                        if let latestDate {
                            DatePicker(title, selection: $selection, in: ...latestDate,
                                       displayedComponents: isDate ? .date : .hourAndMinute)
                        } else {
                            DatePicker(title, selection: $selection,
                                       displayedComponents: isDate ? .date : .hourAndMinute)
                        }
                    }.datePickerStyle(.wheel).labelsHidden().padding(20)
                        .navigationTitle(title).navigationBarTitleDisplayMode(.inline)
                        .toolbar { ToolbarItem(placement: .confirmationAction) {
                            Button("Klaar") { presented = false }
                        } }
                }.presentationDetents([.height(340)])
            }
    }
}

struct SpeciesMapBadge: View {
    let species: Species
    var body: some View {
        Group {
            if UIImage(named: SpeciesMediaRole.classic.assetName(for: species)) != nil {
                PrimaryBirdImage(species: species).frame(width: 28, height: 28)
            } else {
                Image(systemName: "bird").font(.system(size: 20, weight: .light))
            }
        }
        .frame(width: 44, height: 44)
        .background(FieldGuideTheme.ivory, in: Circle())
        .accessibilityLabel(species.dutchName)
    }
}

struct RoundEditAction: View {
    let label: String
    let action: () -> Void
    var body: some View {
        Button(action: action) {
            EditOutlineMark().stroke(style: FieldGuideTheme.navigationStroke).frame(width: 22, height: 22)
                .frame(width: 44, height: 44)
                .background(Circle().stroke(FieldGuideTheme.beige, lineWidth: 0.75))
                .contentShape(Circle())
        }.buttonStyle(.plain).accessibilityLabel(label)
    }
}
struct FineSearchMark: Shape {
    func path(in rect: CGRect) -> Path {
        var path = Path()
        path.addEllipse(in: CGRect(x: 1.5, y: 1.5, width: 15.5, height: 15.5))
        path.move(to: CGPoint(x: 14.8, y: 14.8)); path.addLine(to: CGPoint(x: 22.5, y: 22.5))
        return path.applying(CGAffineTransform(scaleX: rect.width / 24, y: rect.height / 24))
    }
}

struct DetailPageHeader: View {
    let title: String
    let editLabel: String
    var editDisabled = false
    let back: () -> Void
    let edit: () -> Void
    var body: some View {
        ZStack {
            Text(title).font(FieldGuideTheme.sans(17, relativeTo: .headline)).padding(.horizontal, 52)
                .accessibilityAddTraits(.isHeader)
            HStack {
                SpeciesBackButton(action: back)
                Spacer()
                RoundEditAction(label: editLabel, action: edit).disabled(editDisabled)
            }
        }.frame(minHeight: 44).padding(.horizontal, 20).padding(.top, 8).padding(.bottom, 4)
    }
}

struct LiferStar: Shape {
    func path(in rect: CGRect) -> Path {
        let points = (0..<8).map { index -> CGPoint in
            let angle = Double(index) * .pi / 4 - .pi / 2
            let radius: CGFloat = index.isMultiple(of: 2) ? 0.48 : 0.16
            return CGPoint(x: rect.midX + CGFloat(cos(angle)) * rect.width * radius,
                           y: rect.midY + CGFloat(sin(angle)) * rect.height * radius)
        }
        var path = Path()
        for index in points.indices {
            let previous = points[(index + 7) % 8], point = points[index], next = points[(index + 1) % 8]
            let start = CGPoint(x: point.x + (previous.x - point.x) * 0.18, y: point.y + (previous.y - point.y) * 0.18)
            let end = CGPoint(x: point.x + (next.x - point.x) * 0.18, y: point.y + (next.y - point.y) * 0.18)
            if index == 0 { path.move(to: start) } else { path.addLine(to: start) }
            path.addQuadCurve(to: end, control: point)
        }
        path.closeSubpath(); return path
    }
}

struct CameraOutlineMark: Shape {
    func path(in rect: CGRect) -> Path {
        var path = Path()
        path.move(to: CGPoint(x: 3, y: 6))
        path.addLine(to: CGPoint(x: 7, y: 6)); path.addLine(to: CGPoint(x: 9, y: 3))
        path.addLine(to: CGPoint(x: 15, y: 3)); path.addLine(to: CGPoint(x: 17, y: 6))
        path.addLine(to: CGPoint(x: 21, y: 6))
        path.addQuadCurve(to: CGPoint(x: 23, y: 8), control: CGPoint(x: 23, y: 6))
        path.addLine(to: CGPoint(x: 23, y: 19))
        path.addQuadCurve(to: CGPoint(x: 21, y: 21), control: CGPoint(x: 23, y: 21))
        path.addLine(to: CGPoint(x: 3, y: 21))
        path.addQuadCurve(to: CGPoint(x: 1, y: 19), control: CGPoint(x: 1, y: 21))
        path.addLine(to: CGPoint(x: 1, y: 8))
        path.addQuadCurve(to: CGPoint(x: 3, y: 6), control: CGPoint(x: 1, y: 6))
        path.closeSubpath()
        path.addEllipse(in: CGRect(x: 7, y: 8, width: 10, height: 10))
        return path.applying(CGAffineTransform(scaleX: rect.width / 24, y: rect.height / 24))
    }
}

struct BirdTextField: View {
    let placeholder: String
    @Binding var text: String
    init(_ placeholder: String, text: Binding<String>) { self.placeholder = placeholder; _text = text }
    var body: some View {
        TextField(placeholder, text: $text,
                  prompt: Text(placeholder).foregroundColor(FieldGuideTheme.charcoal.opacity(0.78)))
            .foregroundStyle(FieldGuideTheme.charcoal).tint(FieldGuideTheme.charcoal)
            .environment(\.colorScheme, .light)
    }
}

// A moving content anchor resolves against the fixed viewport in the same layout
// pass. Recreating only the scroll view on query changes clears stale lazy-row
// geometry/offsets without replacing the focused search field above it.
struct CatalogResultsScroll<Content: View>: View {
    let resetKey: String
    private let content: Content
    init(resetKey: String, @ViewBuilder content: () -> Content) {
        self.resetKey = resetKey
        self.content = content()
    }
    var body: some View {
        ScrollView {
            content.anchorPreference(key: CatalogContentBounds.self, value: .bounds) { $0 }
        }
        .scrollDismissesKeyboard(.interactively)
        .overlayPreferenceValue(CatalogContentBounds.self) { bounds in
            GeometryReader { viewport in
                let top = bounds.map { viewport[$0].minY } ?? 0
                LinearGradient(colors: [FieldGuideTheme.ivory, FieldGuideTheme.ivory.opacity(0)],
                               startPoint: .top, endPoint: .bottom)
                    .frame(height: 24)
                    .opacity(min(1, max(0, -top / 12)))
            }.allowsHitTesting(false).accessibilityHidden(true)
        }
        .id(resetKey)
    }
}

// Header is outside the scroll viewport, including on photo/audio pages that
// previously installed it as a safe-area inset. Fade starts at the content edge.
struct FixedHeaderScroll<Header: View, Content: View>: View {
    private let header: Header
    private let content: Content
    init(@ViewBuilder header: () -> Header, @ViewBuilder content: () -> Content) {
        self.header = header(); self.content = content()
    }
    var body: some View {
        VStack(spacing: 0) {
            header
            CatalogResultsScroll(resetKey: "fixed-header-content") { content }
        }
    }
}

struct HeaderScrollTop: PreferenceKey {
    static var defaultValue: CGFloat? { nil }
    static func reduce(value: inout CGFloat?, nextValue: () -> CGFloat?) { value = nextValue() ?? value }
}
struct HeaderScrollFade: View {
    let top: CGFloat
    var body: some View {
        LinearGradient(colors: [FieldGuideTheme.ivory, FieldGuideTheme.ivory.opacity(0)], startPoint: .top, endPoint: .bottom)
            .frame(height: 24).opacity(min(1, max(0, -top / 12)))
            .allowsHitTesting(false).accessibilityHidden(true)
    }
}

private struct CatalogContentBounds: PreferenceKey {
    static var defaultValue: Anchor<CGRect>? { nil }
    static func reduce(value: inout Anchor<CGRect>?, nextValue: () -> Anchor<CGRect>?) {
        value = nextValue() ?? value
    }
}

// Use explicit addLine(to:) for connected strokes; Path.addLines starts a new
// subpath and would discard the preceding move point.
// Scale the paths before stroking: every glyph uses the same physical 0.7pt
// line as FineSearchMark, independent of SF Symbols' optical font weights.
struct FineControlIcon: View {
    let symbol: String
    var size: CGFloat = 22
    var body: some View {
        Group {
            if FineControlMark.symbols.contains(symbol) {
                FineControlMark(symbol: symbol).stroke(style: FieldGuideTheme.navigationStroke)
            } else {
                Image(systemName: symbol).font(.system(size: size, weight: .ultraLight))
            }
        }.frame(width: size, height: size).accessibilityHidden(true)
    }
}

struct FineControlMark: Shape {
    static let symbols: Set<String> = ["map", "play", "clock", "plus", "minus", "plus.circle", "minus.circle", "checkmark.circle", "house", "mic", "waveform", "chevron.down", "xmark", "arrow.up.right.square", "arrow.up.arrow.down", "clock.arrow.circlepath"]
    let symbol: String
    func path(in rect: CGRect) -> Path {
        var p = Path()
        switch symbol {
        case "map":
            p.move(to: CGPoint(x: 2, y: 5)); p.addLine(to: CGPoint(x: 8.5, y: 2)); p.addLine(to: CGPoint(x: 15.5, y: 5)); p.addLine(to: CGPoint(x: 22, y: 2)); p.addLine(to: CGPoint(x: 22, y: 19)); p.addLine(to: CGPoint(x: 15.5, y: 22)); p.addLine(to: CGPoint(x: 8.5, y: 19)); p.addLine(to: CGPoint(x: 2, y: 22)); p.closeSubpath()
            for x in [8.5, 15.5] {
                p.move(to: CGPoint(x: x, y: x == 8.5 ? 2 : 5)); p.addLine(to: CGPoint(x: x, y: x == 8.5 ? 19 : 22))
            }
        case "play":
            p.move(to: CGPoint(x: 6, y: 3)); p.addLine(to: CGPoint(x: 21, y: 12)); p.addLine(to: CGPoint(x: 6, y: 21)); p.closeSubpath()
        case "clock", "clock.arrow.circlepath":
            if symbol == "clock" { p.addEllipse(in: CGRect(x: 1, y: 1, width: 22, height: 22)) }
            else {
                p.addArc(center: CGPoint(x: 12, y: 12), radius: 10.5, startAngle: .degrees(-30), endAngle: .degrees(315), clockwise: false)
                p.move(to: CGPoint(x: 15.2, y: 4.6)); p.addLine(to: CGPoint(x: 19.4, y: 4.6)); p.addLine(to: CGPoint(x: 19.4, y: 0.4))
            }
            p.move(to: CGPoint(x: 12, y: 5)); p.addLine(to: CGPoint(x: 12, y: 12)); p.addLine(to: CGPoint(x: 18, y: 12))
        case "plus", "minus", "plus.circle", "minus.circle", "checkmark.circle":
            let circled = symbol.hasSuffix(".circle")
            if circled { p.addEllipse(in: CGRect(x: 1, y: 1, width: 22, height: 22)) }
            if symbol == "checkmark.circle" {
                p.move(to: CGPoint(x: 6, y: 12)); p.addLine(to: CGPoint(x: 10, y: 16)); p.addLine(to: CGPoint(x: 18, y: 8))
            } else {
                let edge: CGFloat = circled ? 6 : 3
                p.move(to: CGPoint(x: edge, y: 12)); p.addLine(to: CGPoint(x: 24 - edge, y: 12))
                if symbol.hasPrefix("plus") { p.move(to: CGPoint(x: 12, y: edge)); p.addLine(to: CGPoint(x: 12, y: 24 - edge)) }
            }
        case "house":
            p.move(to: CGPoint(x: 1, y: 10)); p.addLine(to: CGPoint(x: 12, y: 1)); p.addLine(to: CGPoint(x: 23, y: 10))
            p.move(to: CGPoint(x: 4, y: 7.5)); p.addLine(to: CGPoint(x: 4, y: 22)); p.addLine(to: CGPoint(x: 20, y: 22)); p.addLine(to: CGPoint(x: 20, y: 7.5))
        case "mic":
            p.addRoundedRect(in: CGRect(x: 8, y: 1, width: 8, height: 14), cornerSize: CGSize(width: 4, height: 4))
            p.move(to: CGPoint(x: 5, y: 10)); p.addLine(to: CGPoint(x: 5, y: 12))
            p.addCurve(to: CGPoint(x: 19, y: 12), control1: CGPoint(x: 5, y: 22), control2: CGPoint(x: 19, y: 22))
            p.addLine(to: CGPoint(x: 19, y: 10))
            p.move(to: CGPoint(x: 12, y: 19)); p.addLine(to: CGPoint(x: 12, y: 23))
            p.move(to: CGPoint(x: 8, y: 23)); p.addLine(to: CGPoint(x: 16, y: 23))
        case "waveform":
            for (x, height) in [(2.0, 6.0), (6, 15), (10, 22), (14, 13), (18, 19), (22, 8)] {
                p.move(to: CGPoint(x: x, y: 12 - height / 2)); p.addLine(to: CGPoint(x: x, y: 12 + height / 2))
            }
        case "xmark":
            p.move(to: CGPoint(x: 4, y: 4)); p.addLine(to: CGPoint(x: 20, y: 20))
            p.move(to: CGPoint(x: 20, y: 4)); p.addLine(to: CGPoint(x: 4, y: 20))
        case "arrow.up.right.square":
            p.move(to: CGPoint(x: 11, y: 3)); p.addLine(to: CGPoint(x: 6, y: 3))
            p.addQuadCurve(to: CGPoint(x: 3, y: 6), control: CGPoint(x: 3, y: 3))
            p.addLine(to: CGPoint(x: 3, y: 18))
            p.addQuadCurve(to: CGPoint(x: 6, y: 21), control: CGPoint(x: 3, y: 21))
            p.addLine(to: CGPoint(x: 18, y: 21))
            p.addQuadCurve(to: CGPoint(x: 21, y: 18), control: CGPoint(x: 21, y: 21))
            p.addLine(to: CGPoint(x: 21, y: 13))
            p.move(to: CGPoint(x: 10, y: 14)); p.addLine(to: CGPoint(x: 22, y: 2))
            p.move(to: CGPoint(x: 14, y: 2)); p.addLine(to: CGPoint(x: 22, y: 2)); p.addLine(to: CGPoint(x: 22, y: 10))
        case "chevron.down":
            p.move(to: CGPoint(x: 6, y: 9)); p.addLine(to: CGPoint(x: 12, y: 15)); p.addLine(to: CGPoint(x: 18, y: 9))
        case "arrow.up.arrow.down":
            p.move(to: CGPoint(x: 6, y: 22)); p.addLine(to: CGPoint(x: 6, y: 2))
            p.move(to: CGPoint(x: 1, y: 7)); p.addLine(to: CGPoint(x: 6, y: 2)); p.addLine(to: CGPoint(x: 11, y: 7))
            p.move(to: CGPoint(x: 18, y: 2)); p.addLine(to: CGPoint(x: 18, y: 22))
            p.move(to: CGPoint(x: 13, y: 17)); p.addLine(to: CGPoint(x: 18, y: 22)); p.addLine(to: CGPoint(x: 23, y: 17))
        default: break
        }
        return p.applying(CGAffineTransform(scaleX: rect.width / 24, y: rect.height / 24)
            .concatenating(CGAffineTransform(translationX: rect.minX, y: rect.minY)))
    }
}
